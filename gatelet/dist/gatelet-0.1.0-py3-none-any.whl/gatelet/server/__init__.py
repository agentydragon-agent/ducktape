"""Gatelet server component."""
