"""Command line utilities for Gatelet management."""

from __future__ import annotations

import argparse
import asyncio
from collections.abc import Iterable
import getpass
import tomllib

from gatelet.server.config import CONFIG_PATH, get_settings
from gatelet.server.models import Base, WebhookIntegration, WebhookPayload
from gatelet.server.security import hash_password
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from tomlkit import dumps


def _confirm(prompt: str) -> bool:
    """Prompt user to confirm an action."""
    resp = input(f"{prompt} [y/N]: ").strip().lower()
    return resp == "y"


async def _entity_counts(session: AsyncSession) -> Iterable[tuple[str, int]]:
    """Return row counts for all tables."""
    counts = []
    for table in Base.metadata.sorted_tables:
        result = await session.execute(select(func.count()).select_from(table))
        cnt = result.scalar()
        counts.append((table.name, cnt))
    return counts


async def reset_db() -> None:
    """Drop and recreate tables and populate with sample data."""
    engine = create_async_engine(str(get_settings().database.dsn), future=True)
    session_factory = async_sessionmaker(engine, expire_on_commit=False, autoflush=False)

    async with session_factory() as session:
        counts = await _entity_counts(session)
        if any(cnt > 0 for _, cnt in counts):
            print("Current entity counts:")
            for name, cnt in counts:
                print(f"  {name}: {cnt}")
            if not _confirm("Drop and recreate the database?"):
                print("Aborted.")
                await engine.dispose()
                return

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)

    async with session_factory.begin() as session:
        # Sample integration and payloads for UI demos
        integ = WebhookIntegration(
            name="sample",
            description="Sample integration",
            auth_type="none",
            auth_config={"type": "none"},
            is_enabled=True,
        )
        session.add(integ)
        await session.flush()
        for i in range(3):
            session.add(WebhookPayload(integration_id=integ.id, payload={"sample": i}))
    await engine.dispose()
    print("Database initialized with sample webhook payloads.")


def change_password(password: str | None) -> None:
    """Change admin password stored in the config file."""

    pwd = password or getpass.getpass("New admin password: ")
    hashed = hash_password(pwd)

    with CONFIG_PATH.open("rb") as f:
        data = tomllib.load(f)

    data.setdefault("admin", {})["password_hash"] = hashed

    with CONFIG_PATH.open("w", encoding="utf-8") as f:
        f.write(dumps(data))

    print("Admin password updated in config.")


def main() -> None:
    """Entry point for command line interface."""
    parser = argparse.ArgumentParser(description="Gatelet management utility")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("reset-db", help="Initialize a fresh database")
    pw = sub.add_parser("change-password", help="Change admin password")
    pw.add_argument("password", nargs="?", help="New password")

    args = parser.parse_args()
    if args.cmd == "reset-db":
        asyncio.run(reset_db())
    elif args.cmd == "change-password":
        change_password(args.password)


if __name__ == "__main__":
    main()
